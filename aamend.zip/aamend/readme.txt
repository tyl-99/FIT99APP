video1:
Register, if all the fields are empty than show validation properly, not logic to show for only height and weight
Password validation - combination of characters, numbers
show password option in password field

video2:
hint to let the user understand the term used
recommeded reps, sets, interval for each type of the user before they start the workout

video3:
resolve the issue on validation on more than one exercise with the same name
instead of writiting the date select from the calender when admin create promo

video4:
resolve error on switching between pyramid and cycle 

video5:
Notification, not able to show during presentation

LearningRate_Report
need to send reference related to the parameter set for google teachable machine

image1:
Recommended Weight